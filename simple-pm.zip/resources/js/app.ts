import { createApp } from "vue";
import "../css/app.css";
import App from "./App.vue";

createApp(App).mount("#app");
